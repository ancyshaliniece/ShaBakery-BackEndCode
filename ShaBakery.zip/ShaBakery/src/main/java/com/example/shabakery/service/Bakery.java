package com.example.shabakery.service;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;


@Entity
@Table(name="bakery")
public class Bakery {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="productName")
	private String productName;
	
	@Column(name="productType")
	private String productType;
	
	@Column(name="productTitle")
	private String productTitle;
	
	@Column(name="description")
	private String description;
	
	@Column(name="price")
	private int price;
	
	@Column(name="productQuantity")
	private String productQuantity;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(name="product_images",
	joinColumns = {@JoinColumn(name="product_id")},inverseJoinColumns = {@JoinColumn(name="image_id")})
	private Set<ImageModel> productImage;
	
	

	

	public Bakery(Long id, String productName, String productType, String productTitle, String description,
			int price, String productQuantity) {
		super();
		this.id = id;
		this.productName = productName;
		this.productType = productType;
		this.productTitle = productTitle;
		this.description = description;
		this.price = price;
		this.productQuantity = productQuantity;
	}

	public Bakery(Long id, String productName, String productType, String productTitle, String description, int price,
			String productQuantity, Set<ImageModel> productImage) {
		super();
		this.id = id;
		this.productName = productName;
		this.productType = productType;
		this.productTitle = productTitle;
		this.description = description;
		this.price = price;
		this.productQuantity = productQuantity;
		this.productImage = productImage;
	}

	public Bakery() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(String productQuantity) {
		this.productQuantity = productQuantity;
	}
	public Set<ImageModel> getProductImage() {
		return productImage;
	}

	public void setProductImage(Set<ImageModel> productImage) {
		this.productImage = productImage;
	}
}
