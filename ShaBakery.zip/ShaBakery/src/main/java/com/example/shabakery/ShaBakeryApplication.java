package com.example.shabakery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShaBakeryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShaBakeryApplication.class, args);
	}

}
