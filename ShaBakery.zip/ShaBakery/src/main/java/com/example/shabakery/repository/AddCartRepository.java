package com.example.shabakery.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shabakery.service.AddCart;

public interface AddCartRepository  extends JpaRepository<AddCart, Long>{

}
