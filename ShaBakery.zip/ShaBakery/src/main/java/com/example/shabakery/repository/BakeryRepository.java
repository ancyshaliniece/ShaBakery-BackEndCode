package com.example.shabakery.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shabakery.service.Bakery;


public interface BakeryRepository extends JpaRepository<Bakery, Long> {

	List<Bakery> findAll(Specification<Bakery> fitlerItems);

}
