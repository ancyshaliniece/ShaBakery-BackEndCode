package com.example.shabakery.controller;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.shabakery.repository.AddCartRepository;
import com.example.shabakery.repository.BakeryRepository;
import com.example.shabakery.repository.OrdersRepository;
import com.example.shabakery.service.AddCart;
import com.example.shabakery.service.Bakery;
import com.example.shabakery.service.ImageModel;
import com.example.shabakery.service.Orders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/shaBakery")
public class BakeryController {

	@Autowired
	private BakeryRepository bakeryRepository;
	@Autowired
	private AddCartRepository addCartRepository;
	@Autowired
	private OrdersRepository ordersRepository;
	
	@GetMapping("/getAllBakeryDetails")
	public List<Bakery> getAllBakeryDetails(){
		return bakeryRepository.findAll();
	}
	
	@GetMapping("/filter")
	public List<Bakery> filterBakeryItems(
			@RequestParam (name = "productTitle", required = false) String productTitle){
		Specification<Bakery> fitlerItems=Specification.where(null);
		if(productTitle!=null) {
			fitlerItems = fitlerItems.and((root,query,criteriaBuilder)->
			criteriaBuilder.like(root.get("productTitle"), productTitle));
		}
		
		
		return bakeryRepository.findAll(fitlerItems);
	}
	
	@GetMapping("/GetProductById/{id}")
	public Optional<Bakery> getSingleProduct(@PathVariable Long id) {
		return bakeryRepository.findById(id);
	}
	
//	@PostMapping("/add")
//    public ResponseEntity<String> addProduct(@RequestParam("productName") String productName,
//                                            @RequestParam("productType") String productType,
//                                            @RequestParam("productTitle") String productTitle,
//                                            @RequestParam("description") String description,
//                                            @RequestParam("productQuantity") String productQuantity,
//                                            @RequestParam("price") int price,
//                                            @RequestParam("image") MultipartFile image) throws IOException {
//		Bakery product = new Bakery();
//        product.setProductName(productName);
//        product.setProductType(productType);
//        product.setProductName(productTitle);
//        product.setDescription(description);
//        product.setProductQuantity(productQuantity);
//        product.setPrice(price);
//        product.setImage(image.getBytes());
//        bakeryRepository.save(product);
//        return ResponseEntity.ok("Product added successfully");
//    }
	
	@PostMapping(value= {"/add"},consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
	public Bakery addNewProduct(@RequestParam("productName") String productName,
          @RequestParam("productType") String productType,
          @RequestParam("productTitle") String productTitle,
          @RequestParam("description") String description,
          @RequestParam("productQuantity") String productQuantity,
          @RequestParam("price") int price,
			@RequestPart("productImage") MultipartFile[] productImage) {
		try {
			Bakery bakery = new Bakery();
			bakery.setProductName(productName);
			bakery.setProductType(productType);
			bakery.setProductName(productTitle);
			bakery.setDescription(description);
			bakery.setProductQuantity(productQuantity);
			bakery.setPrice(price);
			Set<ImageModel> images=uploadingImage(productImage);
			bakery.setProductImage(images);
			return bakeryRepository.save(bakery);
		}catch (Exception e){
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	public Set<ImageModel> uploadingImage(MultipartFile[] multipartFiles) throws IOException{
		Set<ImageModel> imageModels = new HashSet<>();
		
		for(MultipartFile file:multipartFiles) {
			ImageModel imageModel=new ImageModel(
					file.getOriginalFilename(),
					file.getContentType(),
					file.getBytes()
					);
			imageModels.add(imageModel);
		}
		return imageModels;
	}
	
	
	// --------------Add Cart---------------
	
	@PostMapping("/addCart")
	public AddCart addAddCart(@RequestBody AddCart addCart) {
		return addCartRepository.save(addCart);
	}
	
	@GetMapping("/getAddCart")
	public List<AddCart> getAddCartItems(){
		return addCartRepository.findAll();
	}
	
	@DeleteMapping("/deleteAddCartItem/{id}")
	public String deleteAddCartItem(@PathVariable Long id) {
		
//		 if(!addCartRepository.existsById(id)) {
//			throw new StudentResourceNotFoundException(id);
//		}
		 addCartRepository.deleteById(id);
		 
		return "Product id "+id+" has been Removed from AddCart";
	}
	
	
	//---------------Orders------------------------
	@PostMapping("/placeOrder")
	public Orders addOrder(@RequestBody Orders order) {
		return ordersRepository.save(order);
	}
	
	@GetMapping("/getOrderItems")
	public List<Orders> getOrderList(){
		return ordersRepository.findAll();
	}

	@DeleteMapping("/deleteOrderedItem/{id}")
	public String deleteOrderedItem(@PathVariable Long id) {
		
//		 if(!addCartRepository.existsById(id)) {
//			throw new StudentResourceNotFoundException(id);
//		}
		 ordersRepository.deleteById(id);
		 
		return "Order id "+id+" has been deleted SuccessFully";
	}
	
}
