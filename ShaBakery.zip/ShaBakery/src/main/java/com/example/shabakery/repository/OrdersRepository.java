package com.example.shabakery.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shabakery.service.Orders;


public interface OrdersRepository extends JpaRepository<Orders, Long>{

}
